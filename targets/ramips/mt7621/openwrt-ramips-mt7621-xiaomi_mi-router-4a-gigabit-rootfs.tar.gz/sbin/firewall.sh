#!/bin/sh

# 启用 SYN-flood 防御
uci set firewall.@defaults[0].syn_flood='1'
# 丢弃无效数据包
uci set firewall.@defaults[0].drop_invalid='1'
# 启用FullCone-NAT
uci set firewall.@defaults[0].fullcone='1'
# 入站数据
uci set firewall.@defaults[0].input='ACCEPT'
# 出站数据
uci set firewall.@defaults[0].output='ACCEPT'
# 转发
uci set firewall.@defaults[0].forward='ACCEPT'
# IP 动态伪装 LAN口
uci set firewall.@zone[0].masq='1'
# MSS 钳制 LAN口
uci set firewall.@zone[0].mtu_fix='1'
# IP 动态伪装 WAN口
uci set firewall.@zone[1].masq='1'
# MSS 钳制 WAN口
uci set firewall.@zone[1].mtu_fix='1'
uci commit firewall

wan_ifname=$(uci get network.wan.ifname 2>/dev/null)
if [ "$wan_ifname" = "" ]; then
	cat /dev/null >/etc/firewall.user
	ipaddr=$(uci get network.lan.ipaddr 2>&1 | awk -F. '{print $1 "." $2 "." $3}')
	for ifname in $(ip route | grep -v 'default' | grep -i $ipaddr | awk '{print $3}'); do echo "iptables -t nat -I POSTROUTING -o $ifname -j MASQUERADE" >>/etc/firewall.user; done
	ipaddr=$(uci get network.lan.ipaddr 2>&1 | awk -F. '{print $1 "." $2 "." $3}')
	for ifname in $(ip route | grep -v 'default' | grep -i $ipaddr | awk '{print $3}'); do echo "ip6tables -t nat -I POSTROUTING -o $ifname -j MASQUERADE" >>/etc/firewall.user; done
elif [ "$wan_ifname" = "wan" ]; then
	cat /dev/null >/etc/firewall.user
	echo "iptables -t nat -A PREROUTING -p tcp --dport 53 -j REDIRECT --to-ports 53" >>/etc/firewall.user
	echo "iptables -t nat -A PREROUTING -p udp --dport 53 -j REDIRECT --to-ports 53" >>/etc/firewall.user
	ipaddr=$(uci get network.lan.ipaddr 2>&1 | awk -F. '{print $1 "." $2 "." $3}')
	for ifname in $(ip route | grep -v 'default' | grep -i $ipaddr | awk '{print $3}'); do echo "ip6tables -t nat -I POSTROUTING -o $ifname -j MASQUERADE" >>/etc/firewall.user; done
fi
